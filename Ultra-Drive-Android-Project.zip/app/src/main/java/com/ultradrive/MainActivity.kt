package com.ultradrive

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.maplibre.android.MapLibre
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.Style

class MainActivity : Activity() {
    private lateinit var mapView: MapView
    private var mapReady = false
    private var mapInstance: MapLibreMap? = null
    private val receiverKeywords = listOf("carplay", "zlink", "tlink", "autokit", "carlink", "cpc200", "carletter")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility =
            (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
             View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
             View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)

        MapLibre.getInstance(this)
        val root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(7, 12, 18)) }
        mapView = MapView(this)
        mapView.onCreate(savedInstanceState)
        root.addView(mapView, FrameLayout.LayoutParams(-1, -1))
        mapView.getMapAsync { map ->
            mapInstance = map
            map.setStyle(Style.Builder().fromUri("https://tiles.openfreemap.org/styles/dark")) { style ->
                mapReady = true
                map.uiSettings.isCompassEnabled = false
                map.uiSettings.isLogoEnabled = false
                map.uiSettings.isAttributionEnabled = true
                enableLocationIfAllowed(map, style)
            }
        }

        val sidebar = buildSidebar()
        val sideParams = FrameLayout.LayoutParams(dp(300), -1, Gravity.START or Gravity.TOP).apply {
            topMargin = dp(10); bottomMargin = dp(126); leftMargin = dp(10)
        }
        root.addView(sidebar, sideParams)
        val dock = buildDock()
        val dockParams = FrameLayout.LayoutParams(-1, dp(104), Gravity.BOTTOM).apply {
            leftMargin = dp(10); rightMargin = dp(10); bottomMargin = dp(10)
        }
        root.addView(dock, dockParams)
        setContentView(root)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 20)
        }
    }

    private fun buildSidebar(): View {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = rounded("#E809111A", 24, "#33495D")
        }
        val temps = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        temps.addView(metric("--°", "OUTSIDE"), LinearLayout.LayoutParams(0, dp(62), 1f))
        temps.addView(dividerVertical(), LinearLayout.LayoutParams(dp(1), dp(48)))
        temps.addView(metric("--°", "CABIN"), LinearLayout.LayoutParams(0, dp(62), 1f))
        panel.addView(temps)
        panel.addView(dividerHorizontal(), LinearLayout.LayoutParams(-1, dp(1)))
        panel.addView(EnergyCarView(this), LinearLayout.LayoutParams(-1, 0, 1f))
        panel.addView(dividerHorizontal(), LinearLayout.LayoutParams(-1, dp(1)))
        val rangeTitle = label("COMBINED RANGE", 12, "#9EADBE", true).apply { gravity = Gravity.CENTER; setPadding(0, dp(10), 0, 0) }
        panel.addView(rangeTitle)
        panel.addView(label("-- km", 32, "#FFFFFF", true).apply { gravity = Gravity.CENTER })
        panel.addView(label("EV -- km   +   FUEL -- km", 12, "#AAB8C8", false).apply { gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(8)) })
        return panel
    }

    private fun metric(value: String, caption: String): View =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            addView(label(value, 24, "#BCEBFF", true).apply { gravity = Gravity.CENTER })
            addView(label(caption, 11, "#9FB7C9", true).apply { gravity = Gravity.CENTER })
        }

    private fun buildDock(): View {
        val dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = rounded("#F009111A", 24, "#33495D")
        }
        val menu = TextView(this).apply {
            text = "▦"; textSize = 30f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = rounded("#FF151F2B", 16, "#34485B")
            setOnClickListener { showAppMenu() }
        }
        dock.addView(menu, LinearLayout.LayoutParams(dp(64), -1))
        val clock = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        val time = android.widget.TextClock(this).apply {
            format12Hour = "h:mm"; format24Hour = "HH:mm"
            textSize = 19f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
        }
        clock.addView(time)
        clock.addView(label("▮▮▮  LTE", 12, "#C9D5E2", false).apply { gravity = Gravity.CENTER })
        dock.addView(clock, LinearLayout.LayoutParams(dp(94), -1))
        listOf("MAP", "♫", "☎", "●").forEach { item ->
            val v = TextView(this).apply {
                text = item; textSize = if (item == "MAP") 11f else 25f
                gravity = Gravity.CENTER; setTextColor(Color.WHITE)
                background = rounded(if (item == "♫") "#FFDA315B" else "#FF182431", 14, "#263747")
            }
            val lp = LinearLayout.LayoutParams(dp(54), dp(54)); lp.marginEnd = dp(10)
            dock.addView(v, lp)
            if (item == "MAP") v.setOnClickListener { Toast.makeText(this, "Native live map is active", Toast.LENGTH_SHORT).show() }
        }
        val spacer = View(this); dock.addView(spacer, LinearLayout.LayoutParams(0, 1, 1f))
        val carplay = TextView(this).apply {
            text = "CARPLAY"; textSize = 13f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = rounded("#FF12334A", 14, "#258FCB")
            setPadding(dp(14), 0, dp(14), 0)
            setOnClickListener { launchCarPlayReceiver() }
        }
        dock.addView(carplay, LinearLayout.LayoutParams(dp(112), dp(56)))
        return dock
    }

    private fun showAppMenu() {
        val choices = arrayOf("Native Live Map", "CarPlay Receiver", "Vehicle data integration")
        AlertDialog.Builder(this).setTitle("Ultra Drive").setItems(choices) { _, which ->
            when (which) {
                0 -> Toast.makeText(this, "Native map is active", Toast.LENGTH_SHORT).show()
                1 -> launchCarPlayReceiver()
                2 -> AlertDialog.Builder(this).setMessage("Vehicle values are shown as placeholders until a compatible vehicle-data source is connected.").setPositiveButton("OK", null).show()
            }
        }.show()
    }

    private fun launchCarPlayReceiver() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, 0).filter { info ->
            val name = info.loadLabel(pm).toString().lowercase()
            receiverKeywords.any { name.contains(it) }
        }
        if (apps.isEmpty()) {
            AlertDialog.Builder(this)
                .setTitle("CarPlay receiver not found")
                .setMessage("Install and pair a compatible third-party CarPlay receiver app or adapter first. Ultra Drive cannot implement Apple's proprietary CarPlay receiver protocol by itself.")
                .setPositiveButton("OK", null).show()
            return
        }
        val labels = apps.map { it.loadLabel(pm).toString() }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Open CarPlay receiver").setItems(labels) { _, which ->
            val ri = apps[which]
            val launch = pm.getLaunchIntentForPackage(ri.activityInfo.packageName)
            if (launch != null) startActivity(launch)
        }.show()
    }

    private fun enableLocationIfAllowed(map: MapLibreMap, style: Style) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            try {
                val options = org.maplibre.android.location.LocationComponentActivationOptions
                    .builder(this, style)
                    .useDefaultLocationEngine(true)
                    .build()
                map.locationComponent.activateLocationComponent(options)
                map.locationComponent.isLocationComponentEnabled = true
            } catch (_: Exception) { }
        }
    }

    private fun label(text: String, size: Int, color: String, bold: Boolean): TextView =
        TextView(this).apply {
            this.text = text; textSize = size.toFloat(); setTextColor(Color.parseColor(color))
            if (bold) typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL
        }

    private fun dividerHorizontal() = View(this).apply { setBackgroundColor(Color.parseColor("#33485A")) }
    private fun dividerVertical() = View(this).apply { setBackgroundColor(Color.parseColor("#33485A")) }

    private fun rounded(fill: String, radius: Int, stroke: String): android.graphics.drawable.Drawable {
        val d = android.graphics.drawable.GradientDrawable()
        d.setColor(Color.parseColor(fill)); d.cornerRadius = dp(radius).toFloat()
        d.setStroke(dp(1), Color.parseColor(stroke)); return d
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 20 && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) {
            mapInstance?.let { map -> map.style?.let { style -> enableLocationIfAllowed(map, style) } }
        }
    }

    override fun onStart() { super.onStart(); mapView.onStart() }
    override fun onResume() { super.onResume(); mapView.onResume() }
    override fun onPause() { mapView.onPause(); super.onPause() }
    override fun onStop() { mapView.onStop(); super.onStop() }
    override fun onLowMemory() { super.onLowMemory(); mapView.onLowMemory() }
    override fun onDestroy() { mapView.onDestroy(); super.onDestroy() }

    override fun onSaveInstanceState(outState: Bundle) { super.onSaveInstanceState(outState); mapView.onSaveInstanceState(outState) }

    private inner class EnergyCarView(context: android.content.Context) : View(context) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f; val cy = height / 2f
            val carW = width * .34f; val carH = height * .72f
            p.style = Paint.Style.FILL; p.color = Color.rgb(15, 27, 39)
            canvas.drawRoundRect(RectF(cx-carW/2, cy-carH/2, cx+carW/2, cy+carH/2), carW/2, carW/2, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = dp(2).toFloat(); p.color = Color.rgb(103, 139, 165)
            canvas.drawRoundRect(RectF(cx-carW/2, cy-carH/2, cx+carW/2, cy+carH/2), carW/2, carW/2, p)
            p.style = Paint.Style.FILL; p.color = Color.rgb(20, 48, 66)
            canvas.drawRoundRect(RectF(cx-carW*.38f, cy-carH*.34f, cx+carW*.38f, cy+carH*.34f), carW*.25f, carW*.25f, p)
            val wheelW = dp(10).toFloat(); val wheelH = carH*.16f
            p.color = Color.rgb(0, 160, 255)
            for (y in listOf(cy-carH*.29f, cy+carH*.13f)) for (x in listOf(cx-carW*.55f, cx+carW*.55f))
                canvas.drawRoundRect(RectF(x-wheelW/2, y-wheelH/2, x+wheelW/2, y+wheelH/2), wheelW/2, wheelW/2, p)
            // Four corner readings: pressure on the first line, tyre temperature below.
            p.style = Paint.Style.FILL
            p.textAlign = Paint.Align.CENTER
            p.typeface = Typeface.DEFAULT_BOLD
            p.textSize = dp(13).toFloat()
            p.color = Color.WHITE
            val leftTextX = cx - width * .37f
            val rightTextX = cx + width * .37f
            val frontY = cy - carH * .25f
            val rearY = cy + carH * .25f
            canvas.drawText("-- psi", leftTextX, frontY, p)
            canvas.drawText("-- psi", rightTextX, frontY, p)
            canvas.drawText("-- psi", leftTextX, rearY, p)
            canvas.drawText("-- psi", rightTextX, rearY, p)
            p.textSize = dp(11).toFloat()
            p.typeface = Typeface.DEFAULT
            p.color = Color.rgb(66, 205, 255)
            canvas.drawText("--°C", leftTextX, frontY + dp(15), p)
            canvas.drawText("--°C", rightTextX, frontY + dp(15), p)
            canvas.drawText("--°C", leftTextX, rearY + dp(15), p)
            canvas.drawText("--°C", rightTextX, rearY + dp(15), p)
            val batt = RectF(cx-carW*.28f, cy-dp(30), cx+carW*.28f, cy+dp(30))
            p.color = Color.rgb(5, 110, 69); canvas.drawRoundRect(batt, dp(7).toFloat(), dp(7).toFloat(), p)
            p.style = Paint.Style.STROKE; p.strokeWidth = dp(2).toFloat(); p.color = Color.rgb(50, 230, 145)
            canvas.drawRoundRect(batt, dp(7).toFloat(), dp(7).toFloat(), p)
            p.style = Paint.Style.FILL; p.color = Color.WHITE; p.textAlign = Paint.Align.CENTER; p.textSize = dp(18).toFloat(); p.typeface = Typeface.DEFAULT_BOLD
            canvas.drawText("—%", cx, cy+dp(6).toFloat(), p)
            p.textSize = dp(10).toFloat(); p.color = Color.rgb(180, 203, 219)
            canvas.drawText("ENERGY FLOW", cx, cy+carH*.47f, p)
            p.color = Color.rgb(0, 160, 255); p.strokeWidth = dp(3).toFloat()
            val path = Path().apply { moveTo(cx, cy-dp(36).toFloat()); lineTo(cx-carW*.55f, cy-carH*.25f) }
            canvas.drawPath(path, p)
            canvas.drawLine(cx, cy-dp(36).toFloat(), cx+carW*.55f, cy-carH*.25f, p)
            canvas.drawLine(cx, cy+dp(36).toFloat(), cx-carW*.55f, cy+carH*.25f, p)
            canvas.drawLine(cx, cy+dp(36).toFloat(), cx+carW*.55f, cy+carH*.25f, p)
        }
    }
}
