# Ultra Drive — Android project

A landscape Android launcher prototype matching the agreed Tesla-inspired dashboard.

## Included
- MapLibre native Android map view using OpenFreeMap's dark style.
- Runtime location permission request and current-location layer.
- Outside/cabin temperature placeholders.
- Vehicle energy-flow illustration and battery placeholder.
- Four tyre pressure/temperature placeholders.
- Combined EV + fuel range placeholder.
- Bottom dock and CarPlay receiver-app launcher discovery.

## Important integration limits
**Native live map:** The app uses MapLibre and the OpenFreeMap hosted style. Internet access is required. Review OpenFreeMap's current usage policy and attribution requirements before public distribution.

**CarPlay:** This app does not implement Apple's proprietary CarPlay receiver protocol. It detects and launches a separately installed compatible receiver app (for example, an adapter/vendor app) if one is present. Actual projection depends on the receiver hardware/app, iPhone pairing, and that vendor's integration. The `CARPLAY` button is an integration hand-off, not a built-in CarPlay decoder.

**Vehicle telemetry:** The temperature, tyre, battery, energy flow and range values are placeholders until a vehicle-specific data source/adapter is connected. Do not treat them as live readings.

## Build
Open this folder in Android Studio (Hedgehog or newer), allow Gradle sync, then choose **Build > Build APK(s)**. The project uses Android Gradle Plugin 8.9.2, Kotlin 2.1.10, compile SDK 35 and MapLibre Android SDK 13.6.1.

No APK is included because this environment does not have Android SDK/Gradle installed. A signed release build also needs a signing key.

## Vehicle data adapter contract (planned)
The first prototype intentionally displays `--` for vehicle values instead of inventing live telemetry. A BYD/Kinex/OBD adapter must supply outside temperature, cabin temperature, four tyre pressures, four tyre temperatures, battery SOC, EV range, fuel range, and signed traction power (positive = discharge to wheels; negative = regen to battery). The energy-flow graphic is ready for that adapter but does not animate until real signed power data is wired in.

## CarPlay hand-off
The CarPlay button searches installed launcher apps by common receiver names and opens the selected receiver. This is an integration hand-off only; it does not capture or decode the CarPlay stream inside this app. A true in-app projection requires the exact receiver vendor SDK/API and compatible receiver hardware.
