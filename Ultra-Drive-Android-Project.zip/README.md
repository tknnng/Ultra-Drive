# Ultra Drive — Android project

Landscape Android dashboard prototype.

## Included
- MapLibre native map using OpenFreeMap dark styling.
- Location permission request and current-location layer.
- Outside/cabin temperature placeholders.
- Energy-flow schematic and battery placeholder.
- Four tyre pressure and four tyre temperature placeholders.
- Combined EV + fuel range placeholder.
- Bottom dock actions for map, music app, phone dialler and app menu.
- DashPlay-specific launch integration for `com.dasharc.dashplay`.

## DashPlay integration status
This update targets DashPlay 0.1.69-beta. The CarPlay button tries `com.shilapi.xcertplay.CarPlayHostActivity`, then `com.shilapi.xcertplay.DashPlayLauncherActivity`, then Android's normal package launch intent.

**This is direct launching, not confirmed in-app embedding.** The `allowEmbedded=true` declaration found on DashPlay's cluster activity does not prove the BYD head unit supports activity embedding or that the CarPlay host is embeddable by a third-party app. The DashPlay map embed service also appears to require a signature-level permission, so Ultra Drive cannot assume it can call that service.

## Vehicle telemetry
All vehicle values remain placeholders. Real BYD telemetry requires a compatible data adapter and testing against the actual vehicle. Tyre temperatures are retained in the display.

## Build
Android Gradle Plugin 8.9.2, Kotlin 2.1.10, compile SDK 35, Gradle 8.11.1 and MapLibre Android SDK 13.6.1. Run `gradle :app:assembleDebug`. APK output: `app/build/outputs/apk/debug/app-debug.apk`.
